const CONFIG = {
  low: { label: "Low", bg: "rgba(47,191,113,0.14)", color: "#1f9c5a" },
  medium: { label: "Medium", bg: "rgba(245,166,35,0.16)", color: "#c98212" },
  high: { label: "High", bg: "rgba(229,72,77,0.14)", color: "#c8383d" },
};

export default function PriorityBadge({ priority }) {
  const cfg = CONFIG[priority] || CONFIG.medium;
  return (
    <span className="badge" style={{ background: cfg.bg, color: cfg.color }}>
      {cfg.label}
    </span>
  );
}
