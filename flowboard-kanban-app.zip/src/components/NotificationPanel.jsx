import { CheckCircle2, Clock, FolderPlus, MessageSquare } from "lucide-react";
import { useBoard } from "../context/BoardContext";
import { relativeTime } from "../utils/date";
import EmptyState from "./EmptyState";

const ICONS = {
  completed: CheckCircle2,
  due: Clock,
  project: FolderPlus,
  comment: MessageSquare,
};

export default function NotificationPanel() {
  const { notifications, markNotificationRead, markAllNotificationsRead } = useBoard();

  return (
    <div className="notif-panel card-surface fade-in">
      <div className="notif-panel-header">
        <h4>Notifications</h4>
        <button className="link-btn" onClick={markAllNotificationsRead}>
          Mark all read
        </button>
      </div>
      <div className="notif-list">
        {notifications.length === 0 && (
          <EmptyState icon="🔔" title="All caught up" message="You have no notifications." />
        )}
        {notifications.map((n) => {
          const Icon = ICONS[n.type] || Clock;
          return (
            <button
              key={n.id}
              className={`notif-item ${n.read ? "" : "unread"}`}
              onClick={() => markNotificationRead(n.id)}
            >
              <span className={`notif-icon notif-${n.type}`}>
                <Icon size={15} />
              </span>
              <span className="notif-text">
                <span>{n.text}</span>
                <span className="notif-time">{relativeTime(n.at)}</span>
              </span>
              {!n.read && <span className="notif-unread-dot" />}
            </button>
          );
        })}
      </div>
    </div>
  );
}
