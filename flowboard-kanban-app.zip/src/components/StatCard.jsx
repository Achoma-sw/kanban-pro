export default function StatCard({ icon, label, value, tint, sub }) {
  return (
    <div className="stat-card card-surface fade-in">
      <div className="stat-icon" style={{ background: tint }}>
        {icon}
      </div>
      <div>
        <div className="stat-value">{value}</div>
        <div className="stat-label">{label}</div>
        {sub && <div className="stat-sub">{sub}</div>}
      </div>
    </div>
  );
}
