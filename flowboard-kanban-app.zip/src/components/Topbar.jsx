import { useState, useRef, useEffect } from "react";
import { Search, Sun, Moon, Bell, Menu, Command } from "lucide-react";
import { useTheme } from "../context/ThemeContext";
import { useBoard } from "../context/BoardContext";
import NotificationPanel from "./NotificationPanel";
import SearchResults from "./SearchResults";

export default function Topbar({ onOpenMobileSidebar, onOpenCommandPalette, pageTitle }) {
  const { theme, toggleTheme } = useTheme();
  const { notifications } = useBoard();
  const [query, setQuery] = useState("");
  const [notifOpen, setNotifOpen] = useState(false);
  const searchRef = useRef(null);
  const unread = notifications.filter((n) => !n.read).length;

  useEffect(() => {
    const handler = (e) => {
      if (searchRef.current && !searchRef.current.contains(e.target)) setQuery((q) => q);
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, []);

  return (
    <header className="topbar">
      <div className="topbar-left">
        <button className="btn-icon mobile-only" onClick={onOpenMobileSidebar} aria-label="Open menu">
          <Menu size={20} />
        </button>
        <h1 className="page-title">{pageTitle}</h1>
      </div>

      <div className="topbar-search" ref={searchRef}>
        <Search size={16} className="search-icon" />
        <input
          type="text"
          placeholder="Search tasks, labels, projects…"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          aria-label="Search"
        />
        <kbd className="search-kbd">/</kbd>
        {query.trim().length > 0 && <SearchResults query={query} onClose={() => setQuery("")} />}
      </div>

      <div className="topbar-right">
        <button className="btn-icon" onClick={onOpenCommandPalette} title="Command palette (Ctrl+K)">
          <Command size={18} />
        </button>
        <button className="btn-icon" onClick={toggleTheme} aria-label="Toggle theme">
          {theme === "light" ? <Moon size={18} /> : <Sun size={18} />}
        </button>
        <div style={{ position: "relative" }}>
          <button className="btn-icon" onClick={() => setNotifOpen((v) => !v)} aria-label="Notifications">
            <Bell size={18} />
            {unread > 0 && <span className="notif-dot">{unread}</span>}
          </button>
          {notifOpen && <NotificationPanel onClose={() => setNotifOpen(false)} />}
        </div>
      </div>
    </header>
  );
}
