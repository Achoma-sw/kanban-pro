import { useMemo } from "react";
import { useNavigate } from "react-router-dom";
import { FolderKanban, Tag, CheckSquare } from "lucide-react";
import { useBoard } from "../context/BoardContext";

export default function SearchResults({ query, onClose }) {
  const { projects } = useBoard();
  const navigate = useNavigate();
  const q = query.trim().toLowerCase();

  const results = useMemo(() => {
    const projectMatches = projects.filter((p) => p.name.toLowerCase().includes(q));
    const taskMatches = [];
    const labelSet = new Set();
    projects.forEach((p) => {
      Object.values(p.tasks).forEach((t) => {
        if (t.title.toLowerCase().includes(q)) {
          taskMatches.push({ project: p, task: t });
        }
        t.labels.forEach((l) => {
          if (l.toLowerCase().includes(q)) labelSet.add(l);
        });
      });
    });
    return { projectMatches: projectMatches.slice(0, 4), taskMatches: taskMatches.slice(0, 6), labels: [...labelSet].slice(0, 4) };
  }, [projects, q]);

  const hasResults = results.projectMatches.length || results.taskMatches.length || results.labels.length;

  return (
    <div className="search-results card-surface fade-in">
      {!hasResults && <div className="search-empty">No matches for "{query}"</div>}

      {results.projectMatches.length > 0 && (
        <div className="search-group">
          <div className="search-group-title">Projects</div>
          {results.projectMatches.map((p) => (
            <button
              key={p.id}
              className="search-item"
              onClick={() => {
                navigate(`/boards/${p.id}`);
                onClose();
              }}
            >
              <FolderKanban size={14} />
              <span>{p.name}</span>
            </button>
          ))}
        </div>
      )}

      {results.taskMatches.length > 0 && (
        <div className="search-group">
          <div className="search-group-title">Tasks</div>
          {results.taskMatches.map(({ project, task }) => (
            <button
              key={task.id}
              className="search-item"
              onClick={() => {
                navigate(`/boards/${project.id}?task=${task.id}`);
                onClose();
              }}
            >
              <CheckSquare size={14} />
              <span>{task.title}</span>
              <span className="search-item-sub">{project.name}</span>
            </button>
          ))}
        </div>
      )}

      {results.labels.length > 0 && (
        <div className="search-group">
          <div className="search-group-title">Labels</div>
          <div className="search-label-row">
            {results.labels.map((l) => (
              <span key={l} className="badge search-label">
                <Tag size={11} /> {l}
              </span>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
