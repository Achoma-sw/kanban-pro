export default function Avatar({ user, size = 28 }) {
  if (!user) {
    return (
      <div
        className="avatar avatar-empty"
        style={{ width: size, height: size, fontSize: size * 0.4 }}
        title="Unassigned"
      >
        ?
      </div>
    );
  }
  return (
    <div
      className="avatar"
      style={{ width: size, height: size, background: user.color, fontSize: size * 0.38 }}
      title={user.name}
    >
      {user.initials}
    </div>
  );
}
