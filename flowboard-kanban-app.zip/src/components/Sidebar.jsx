import { NavLink, useNavigate } from "react-router-dom";
import {
  LayoutGrid,
  CalendarDays,
  Activity,
  Settings,
  Star,
  Plus,
  ChevronsLeft,
  ChevronsRight,
  LogOut,
} from "lucide-react";
import { useBoard } from "../context/BoardContext";
import { useAuth } from "../context/AuthContext";

export default function Sidebar({ collapsed, onToggle, mobileOpen, onCloseMobile }) {
  const { projects, createProject } = useBoard();
  const { logout, user } = useAuth();
  const navigate = useNavigate();
  const active = projects.filter((p) => !p.archived);
  const favorites = active.filter((p) => p.favorite);

  const handleNewProject = () => {
    const name = window.prompt("Name your new project");
    if (name && name.trim()) {
      const project = createProject(name.trim());
      navigate(`/boards/${project.id}`);
    }
  };

  return (
    <>
      {mobileOpen && <div className="sidebar-scrim" onClick={onCloseMobile} />}
      <aside className={`sidebar ${collapsed ? "collapsed" : ""} ${mobileOpen ? "open" : ""}`}>
        <div className="sidebar-brand">
          <div className="brand-mark">◈</div>
          {!collapsed && <span>Flowboard</span>}
        </div>

        <nav className="sidebar-nav">
          <NavLink to="/dashboard" className="sidebar-link" onClick={onCloseMobile}>
            <LayoutGrid size={18} />
            {!collapsed && <span>Dashboard</span>}
          </NavLink>
          <NavLink to="/calendar" className="sidebar-link" onClick={onCloseMobile}>
            <CalendarDays size={18} />
            {!collapsed && <span>Calendar</span>}
          </NavLink>
          <NavLink to="/activity" className="sidebar-link" onClick={onCloseMobile}>
            <Activity size={18} />
            {!collapsed && <span>Activity</span>}
          </NavLink>
          <NavLink to="/settings" className="sidebar-link" onClick={onCloseMobile}>
            <Settings size={18} />
            {!collapsed && <span>Settings</span>}
          </NavLink>
        </nav>

        {favorites.length > 0 && !collapsed && (
          <div className="sidebar-section">
            <div className="sidebar-section-title">Favorites</div>
            {favorites.map((p) => (
              <NavLink key={p.id} to={`/boards/${p.id}`} className="sidebar-link project-link" onClick={onCloseMobile}>
                <Star size={14} fill="currentColor" style={{ color: "var(--warning)" }} />
                <span className="project-emoji">{p.icon}</span>
                <span className="truncate">{p.name}</span>
              </NavLink>
            ))}
          </div>
        )}

        <div className="sidebar-section grow">
          {!collapsed && (
            <div className="sidebar-section-title-row">
              <span className="sidebar-section-title">Projects</span>
              <button className="btn-icon" onClick={handleNewProject} aria-label="Create project">
                <Plus size={16} />
              </button>
            </div>
          )}
          <div className="sidebar-projects">
            {active.map((p) => (
              <NavLink key={p.id} to={`/boards/${p.id}`} className="sidebar-link project-link" onClick={onCloseMobile}>
                <span className="project-dot" style={{ background: p.color }} />
                {!collapsed && <span className="truncate">{p.name}</span>}
              </NavLink>
            ))}
          </div>
          {collapsed && (
            <button className="btn-icon" style={{ marginTop: 8 }} onClick={handleNewProject} aria-label="Create project">
              <Plus size={16} />
            </button>
          )}
        </div>

        <div className="sidebar-footer">
          {!collapsed && user && (
            <div className="sidebar-user">
              <div className="avatar" style={{ background: user.color, width: 32, height: 32 }}>
                {user.initials}
              </div>
              <div>
                <div className="sidebar-user-name">{user.name}</div>
                <div className="sidebar-user-role">{user.role}</div>
              </div>
            </div>
          )}
          <button className="btn-icon" onClick={logout} aria-label="Log out" title="Log out">
            <LogOut size={18} />
          </button>
        </div>

        <button className="sidebar-collapse-btn" onClick={onToggle} aria-label="Toggle sidebar width">
          {collapsed ? <ChevronsRight size={16} /> : <ChevronsLeft size={16} />}
        </button>
      </aside>
    </>
  );
}
