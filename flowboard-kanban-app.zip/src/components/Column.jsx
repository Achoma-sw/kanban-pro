import { useState, useRef } from "react";
import { Plus, MoreHorizontal, Pencil, Trash2 } from "lucide-react";
import TaskCard from "./TaskCard";
import { useBoard } from "../context/BoardContext";

export default function Column({
  project,
  column,
  index,
  onOpenTask,
  onDragStartTask,
  onDropTask,
  draggingTaskId,
  onColumnDragStart,
  onColumnDrop,
}) {
  const { renameColumn, deleteColumn, addTask } = useBoard();
  const [editingName, setEditingName] = useState(false);
  const [nameValue, setNameValue] = useState(column.name);
  const [menuOpen, setMenuOpen] = useState(false);
  const [adding, setAdding] = useState(false);
  const [newTitle, setNewTitle] = useState("");
  const [dragOver, setDragOver] = useState(false);
  const menuRef = useRef(null);

  const tasks = column.taskIds.map((id) => project.tasks[id]).filter(Boolean);
  const doneCount = tasks.filter((t) => t.completed).length;
  const pct = tasks.length ? Math.round((doneCount / tasks.length) * 100) : 0;

  const commitRename = () => {
    if (nameValue.trim()) renameColumn(project.id, column.id, nameValue.trim());
    setEditingName(false);
  };

  const submitNewTask = (e) => {
    e.preventDefault();
    if (newTitle.trim()) {
      addTask(project.id, column.id, { title: newTitle.trim() });
      setNewTitle("");
    }
    setAdding(false);
  };

  return (
    <div
      className={`kanban-column ${dragOver ? "drag-over" : ""}`}
      draggable
      onDragStart={(e) => {
        e.stopPropagation();
        onColumnDragStart(index);
      }}
      onDragOver={(e) => e.preventDefault()}
      onDrop={(e) => {
        e.preventDefault();
        onColumnDrop(index);
        setDragOver(false);
      }}
    >
      <div className="kanban-column-header">
        <div className="column-title-row">
          <span className="column-progress-dot" style={{ "--pct": `${pct}%` }} />
          {editingName ? (
            <input
              autoFocus
              className="column-name-input"
              value={nameValue}
              onChange={(e) => setNameValue(e.target.value)}
              onBlur={commitRename}
              onKeyDown={(e) => e.key === "Enter" && commitRename()}
            />
          ) : (
            <h3>{column.name}</h3>
          )}
          <span className="column-count">{tasks.length}</span>
        </div>
        <div className="column-menu" ref={menuRef}>
          <button className="btn-icon" onClick={() => setMenuOpen((v) => !v)} aria-label="Column options">
            <MoreHorizontal size={16} />
          </button>
          {menuOpen && (
            <div className="task-card-dropdown fade-in">
              <button
                onClick={() => {
                  setEditingName(true);
                  setMenuOpen(false);
                }}
              >
                <Pencil size={14} /> Rename
              </button>
              <button
                className="danger"
                onClick={() => {
                  deleteColumn(project.id, column.id);
                  setMenuOpen(false);
                }}
              >
                <Trash2 size={14} /> Delete column
              </button>
            </div>
          )}
        </div>
      </div>

      <div
        className={`kanban-column-body ${dragOver ? "drop-target" : ""}`}
        onDragOver={(e) => {
          e.preventDefault();
          setDragOver(true);
        }}
        onDragLeave={() => setDragOver(false)}
        onDrop={(e) => {
          e.preventDefault();
          setDragOver(false);
          onDropTask(column.id);
        }}
      >
        {tasks.length === 0 && !adding && <div className="column-empty">Drop a task here</div>}
        {tasks.map((task) => (
          <TaskCard
            key={task.id}
            project={project}
            task={task}
            onOpen={onOpenTask}
            onDragStart={onDragStartTask}
            onDragEnd={() => {}}
            dragging={draggingTaskId === task.id}
          />
        ))}
      </div>

      {adding ? (
        <form className="column-add-form" onSubmit={submitNewTask}>
          <input
            autoFocus
            placeholder="Task title…"
            value={newTitle}
            onChange={(e) => setNewTitle(e.target.value)}
            onKeyDown={(e) => e.key === "Escape" && setAdding(false)}
          />
          <div className="column-add-actions">
            <button type="submit" className="btn btn-primary btn-sm">
              Add
            </button>
            <button type="button" className="btn btn-ghost btn-sm" onClick={() => setAdding(false)}>
              Cancel
            </button>
          </div>
        </form>
      ) : (
        <button className="column-add-btn" onClick={() => setAdding(true)}>
          <Plus size={15} /> Add task
        </button>
      )}
    </div>
  );
}
