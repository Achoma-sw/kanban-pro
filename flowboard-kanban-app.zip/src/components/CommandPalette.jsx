import { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { LayoutGrid, CalendarDays, Activity, Settings, FolderKanban, Sun, Moon, Search } from "lucide-react";
import { useBoard } from "../context/BoardContext";
import { useTheme } from "../context/ThemeContext";

export default function CommandPalette({ onClose }) {
  const { projects } = useBoard();
  const { theme, toggleTheme } = useTheme();
  const navigate = useNavigate();
  const [query, setQuery] = useState("");

  useEffect(() => {
    const onKey = (e) => e.key === "Escape" && onClose();
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, [onClose]);

  const commands = useMemo(() => {
    const base = [
      { id: "dashboard", label: "Go to Dashboard", icon: LayoutGrid, run: () => navigate("/dashboard") },
      { id: "calendar", label: "Go to Calendar", icon: CalendarDays, run: () => navigate("/calendar") },
      { id: "activity", label: "Go to Activity", icon: Activity, run: () => navigate("/activity") },
      { id: "settings", label: "Go to Settings", icon: Settings, run: () => navigate("/settings") },
      {
        id: "theme",
        label: theme === "light" ? "Switch to dark mode" : "Switch to light mode",
        icon: theme === "light" ? Moon : Sun,
        run: toggleTheme,
      },
      ...projects
        .filter((p) => !p.archived)
        .map((p) => ({
          id: p.id,
          label: `Open board: ${p.name}`,
          icon: FolderKanban,
          run: () => navigate(`/boards/${p.id}`),
        })),
    ];
    if (!query.trim()) return base;
    return base.filter((c) => c.label.toLowerCase().includes(query.toLowerCase()));
  }, [projects, query, theme, navigate, toggleTheme]);

  return (
    <div className="modal-overlay" onMouseDown={onClose}>
      <div className="command-palette card-surface fade-in" onMouseDown={(e) => e.stopPropagation()}>
        <div className="command-palette-input">
          <Search size={16} />
          <input
            autoFocus
            placeholder="Type a command or search…"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
          />
          <kbd>Esc</kbd>
        </div>
        <div className="command-palette-list">
          {commands.length === 0 && <div className="search-empty">No matching commands</div>}
          {commands.map((c) => (
            <button
              key={c.id}
              className="command-item"
              onClick={() => {
                c.run();
                onClose();
              }}
            >
              <c.icon size={16} />
              <span>{c.label}</span>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
