import { useState } from "react";
import { Plus } from "lucide-react";
import Column from "./Column";
import { useBoard } from "../context/BoardContext";

export default function Board({ project, onOpenTask }) {
  const [draggingTaskId, setDraggingTaskId] = useState(null);
  const [draggingFromColumn, setDraggingFromColumn] = useState(null);
  const [draggingColumnIndex, setDraggingColumnIndex] = useState(null);
  const [addingColumn, setAddingColumn] = useState(false);
  const [newColumnName, setNewColumnName] = useState("");

  const { moveTask, addColumn, reorderColumns } = useBoard();

  const handleDragStartTask = (e, taskId) => {
    const fromColumn = project.columns.find((c) => c.taskIds.includes(taskId));
    setDraggingTaskId(taskId);
    setDraggingFromColumn(fromColumn?.id || null);
    e.dataTransfer.effectAllowed = "move";
  };

  const handleDropTask = (toColumnId) => {
    if (draggingTaskId && draggingFromColumn) {
      moveTask(project.id, draggingTaskId, draggingFromColumn, toColumnId);
    }
    setDraggingTaskId(null);
    setDraggingFromColumn(null);
  };

  const handleColumnDrop = (toIndex) => {
    if (draggingColumnIndex !== null && draggingColumnIndex !== toIndex) {
      reorderColumns(project.id, draggingColumnIndex, toIndex);
    }
    setDraggingColumnIndex(null);
  };

  const submitNewColumn = (e) => {
    e.preventDefault();
    if (newColumnName.trim()) {
      addColumn(project.id, newColumnName.trim());
      setNewColumnName("");
    }
    setAddingColumn(false);
  };

  return (
    <div className="board-scroll">
      {project.columns.map((column, index) => (
        <Column
          key={column.id}
          project={project}
          column={column}
          index={index}
          onOpenTask={onOpenTask}
          onDragStartTask={handleDragStartTask}
          onDropTask={handleDropTask}
          draggingTaskId={draggingTaskId}
          onColumnDragStart={setDraggingColumnIndex}
          onColumnDrop={handleColumnDrop}
        />
      ))}

      <div className="add-column-slot">
        {addingColumn ? (
          <form className="column-add-form card-surface" onSubmit={submitNewColumn}>
            <input
              autoFocus
              placeholder="Column name…"
              value={newColumnName}
              onChange={(e) => setNewColumnName(e.target.value)}
              onKeyDown={(e) => e.key === "Escape" && setAddingColumn(false)}
            />
            <div className="column-add-actions">
              <button type="submit" className="btn btn-primary btn-sm">
                Add column
              </button>
              <button type="button" className="btn btn-ghost btn-sm" onClick={() => setAddingColumn(false)}>
                Cancel
              </button>
            </div>
          </form>
        ) : (
          <button className="add-column-btn" onClick={() => setAddingColumn(true)}>
            <Plus size={16} /> Add column
          </button>
        )}
      </div>
    </div>
  );
}
