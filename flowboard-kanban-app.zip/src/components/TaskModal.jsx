import { useState, useEffect, useRef } from "react";
import {
  X,
  CheckSquare,
  Square,
  Plus,
  Trash2,
  Paperclip,
  MessageSquare,
  Clock,
  Tag as TagIcon,
} from "lucide-react";
import { useBoard } from "../context/BoardContext";
import { useAuth } from "../context/AuthContext";
import Avatar from "./Avatar";
import { formatDate, relativeTime } from "../utils/date";

const PRIORITIES = ["low", "medium", "high"];
const LABEL_SUGGESTIONS = ["Design", "Frontend", "Backend", "Content", "Research", "Security", "DevOps", "Growth", "Accessibility"];

export default function TaskModal({ project, task, onClose }) {
  const {
    updateTask,
    deleteTask,
    duplicateTask,
    toggleTaskComplete,
    addChecklistItem,
    toggleChecklistItem,
    deleteChecklistItem,
    addComment,
    users,
    markTaskViewed,
  } = useBoard();
  const { user } = useAuth();

  const [title, setTitle] = useState(task.title);
  const [description, setDescription] = useState(task.description);
  const [newChecklistText, setNewChecklistText] = useState("");
  const [newComment, setNewComment] = useState("");
  const [labelInput, setLabelInput] = useState("");
  const titleRef = useRef(null);

  useEffect(() => {
    markTaskViewed(project.id, task.id);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [task.id]);

  useEffect(() => {
    const onKey = (e) => e.key === "Escape" && onClose();
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, [onClose]);

  const commitTitle = () => {
    if (title.trim() && title !== task.title) {
      updateTask(project.id, task.id, { title: title.trim() }, `Renamed to "${title.trim()}"`);
    }
  };

  const commitDescription = () => {
    if (description !== task.description) {
      updateTask(project.id, task.id, { description }, "Updated description");
    }
  };

  const columnId = project.columns.find((c) => c.taskIds.includes(task.id))?.id;
  const assignee = users.find((u) => u.id === task.assigneeId);
  const doneCount = task.checklist.filter((c) => c.done).length;
  const checklistPct = task.checklist.length ? Math.round((doneCount / task.checklist.length) * 100) : 0;

  const addLabel = (label) => {
    if (!label.trim() || task.labels.includes(label.trim())) return;
    updateTask(project.id, task.id, { labels: [...task.labels, label.trim()] }, `Added label "${label.trim()}"`);
    setLabelInput("");
  };

  const removeLabel = (label) => {
    updateTask(project.id, task.id, { labels: task.labels.filter((l) => l !== label) });
  };

  return (
    <div className="modal-overlay" onMouseDown={onClose}>
      <div className="modal-panel fade-in" onMouseDown={(e) => e.stopPropagation()}>
        <div className="modal-header">
          <label className="task-complete-check">
            <button
              className={`check-circle ${task.completed ? "checked" : ""}`}
              onClick={() => toggleTaskComplete(project.id, task.id)}
              aria-label="Toggle complete"
            >
              {task.completed && <CheckSquare size={14} />}
            </button>
          </label>
          <input
            ref={titleRef}
            className="modal-title-input"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            onBlur={commitTitle}
            onKeyDown={(e) => e.key === "Enter" && titleRef.current.blur()}
          />
          <button className="btn-icon" onClick={onClose} aria-label="Close">
            <X size={20} />
          </button>
        </div>

        <div className="modal-body">
          <div className="modal-main">
            <section className="modal-section">
              <h4>Description</h4>
              <textarea
                rows={4}
                placeholder="Add a more detailed description…"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                onBlur={commitDescription}
              />
            </section>

            <section className="modal-section">
              <div className="section-header-row">
                <h4>
                  Checklist {task.checklist.length > 0 && `(${doneCount}/${task.checklist.length})`}
                </h4>
              </div>
              {task.checklist.length > 0 && (
                <div className="checklist-progress">
                  <div className="checklist-progress-fill" style={{ width: `${checklistPct}%` }} />
                </div>
              )}
              <ul className="checklist">
                {task.checklist.map((item) => (
                  <li key={item.id} className="checklist-item">
                    <button onClick={() => toggleChecklistItem(project.id, task.id, item.id)}>
                      {item.done ? <CheckSquare size={16} /> : <Square size={16} />}
                    </button>
                    <span className={item.done ? "strike" : ""}>{item.text}</span>
                    <button className="checklist-remove" onClick={() => deleteChecklistItem(project.id, task.id, item.id)}>
                      <Trash2 size={13} />
                    </button>
                  </li>
                ))}
              </ul>
              <form
                className="inline-add-form"
                onSubmit={(e) => {
                  e.preventDefault();
                  if (newChecklistText.trim()) {
                    addChecklistItem(project.id, task.id, newChecklistText.trim());
                    setNewChecklistText("");
                  }
                }}
              >
                <Plus size={14} />
                <input
                  placeholder="Add checklist item…"
                  value={newChecklistText}
                  onChange={(e) => setNewChecklistText(e.target.value)}
                />
              </form>
            </section>

            <section className="modal-section">
              <h4>
                <Paperclip size={14} style={{ verticalAlign: "-2px" }} /> Attachments
              </h4>
              {task.attachments.length === 0 ? (
                <p className="muted-text">No attachments yet. This is a UI-only demo, so uploads aren't wired up.</p>
              ) : (
                <ul>
                  {task.attachments.map((a) => (
                    <li key={a.id}>{a.name}</li>
                  ))}
                </ul>
              )}
            </section>

            <section className="modal-section">
              <h4>
                <MessageSquare size={14} style={{ verticalAlign: "-2px" }} /> Comments
              </h4>
              <div className="comment-list">
                {task.comments.map((c) => {
                  const author = users.find((u) => u.id === c.authorId);
                  return (
                    <div key={c.id} className="comment">
                      <Avatar user={author} size={26} />
                      <div>
                        <div className="comment-meta">
                          <strong>{author?.name || "Someone"}</strong>
                          <span>{relativeTime(c.at)}</span>
                        </div>
                        <p>{c.text}</p>
                      </div>
                    </div>
                  );
                })}
              </div>
              <form
                className="inline-add-form"
                onSubmit={(e) => {
                  e.preventDefault();
                  if (newComment.trim()) {
                    addComment(project.id, task.id, newComment.trim(), user?.id || "u1");
                    setNewComment("");
                  }
                }}
              >
                <Avatar user={user} size={24} />
                <input
                  placeholder="Write a comment…"
                  value={newComment}
                  onChange={(e) => setNewComment(e.target.value)}
                />
              </form>
            </section>

            <section className="modal-section">
              <h4>
                <Clock size={14} style={{ verticalAlign: "-2px" }} /> Activity
              </h4>
              <ul className="activity-log">
                {task.activity.map((a) => (
                  <li key={a.id}>
                    <span>{a.text}</span>
                    <span className="activity-time">{relativeTime(a.at)}</span>
                  </li>
                ))}
              </ul>
            </section>
          </div>

          <aside className="modal-sidebar">
            <div className="field">
              <label style={{ display: "flex", alignItems: "center", gap: 6 }}>
                Assignee
                {assignee && <Avatar user={assignee} size={18} />}
              </label>
              <select
                value={task.assigneeId || ""}
                onChange={(e) => updateTask(project.id, task.id, { assigneeId: e.target.value || null }, "Changed assignee")}
              >
                <option value="">Unassigned</option>
                {users.map((u) => (
                  <option key={u.id} value={u.id}>
                    {u.name}
                  </option>
                ))}
              </select>
            </div>

            <div className="field">
              <label>Priority</label>
              <select
                value={task.priority}
                onChange={(e) => updateTask(project.id, task.id, { priority: e.target.value }, `Set priority to ${e.target.value}`)}
              >
                {PRIORITIES.map((p) => (
                  <option key={p} value={p}>
                    {p[0].toUpperCase() + p.slice(1)}
                  </option>
                ))}
              </select>
            </div>

            <div className="field">
              <label>Due date</label>
              <input
                type="date"
                value={task.dueDate ? task.dueDate.slice(0, 10) : ""}
                onChange={(e) =>
                  updateTask(
                    project.id,
                    task.id,
                    { dueDate: e.target.value ? new Date(e.target.value).toISOString() : null },
                    "Changed due date"
                  )
                }
              />
              {task.dueDate && <span className="muted-text small">{formatDate(task.dueDate)}</span>}
            </div>

            <div className="field">
              <label>
                <TagIcon size={12} style={{ verticalAlign: "-2px" }} /> Labels
              </label>
              <div className="label-chip-row">
                {task.labels.map((l) => (
                  <span key={l} className="chip removable">
                    {l}
                    <button onClick={() => removeLabel(l)} aria-label={`Remove ${l}`}>
                      <X size={11} />
                    </button>
                  </span>
                ))}
              </div>
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  addLabel(labelInput);
                }}
              >
                <input
                  placeholder="Add label + Enter"
                  value={labelInput}
                  onChange={(e) => setLabelInput(e.target.value)}
                  list="label-suggestions"
                />
                <datalist id="label-suggestions">
                  {LABEL_SUGGESTIONS.map((l) => (
                    <option key={l} value={l} />
                  ))}
                </datalist>
              </form>
            </div>

            <div className="modal-sidebar-actions">
              <button
                className="btn btn-outline"
                onClick={() => {
                  duplicateTask(project.id, columnId, task.id);
                  onClose();
                }}
              >
                Duplicate task
              </button>
              <button
                className="btn btn-danger-outline"
                onClick={() => {
                  deleteTask(project.id, task.id);
                  onClose();
                }}
              >
                <Trash2 size={14} /> Delete task
              </button>
            </div>
          </aside>
        </div>
      </div>
    </div>
  );
}
