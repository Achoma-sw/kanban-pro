import { MessageSquare, Paperclip, CheckSquare, MoreHorizontal, Copy, Trash2 } from "lucide-react";
import { useState, useRef, useEffect } from "react";
import PriorityBadge from "./PriorityBadge";
import Avatar from "./Avatar";
import { formatDate, isOverdue, isToday } from "../utils/date";
import { useBoard } from "../context/BoardContext";

export default function TaskCard({ project, task, onOpen, onDragStart, onDragEnd, dragging }) {
  const { users, duplicateTask, deleteTask, toggleTaskComplete } = useBoard();
  const assignee = users.find((u) => u.id === task.assigneeId);
  const [menuOpen, setMenuOpen] = useState(false);
  const menuRef = useRef(null);
  const checklistDone = task.checklist.filter((c) => c.done).length;
  const overdue = isOverdue(task.dueDate) && !task.completed;
  const dueToday = isToday(task.dueDate) && !task.completed;

  useEffect(() => {
    const handler = (e) => {
      if (menuRef.current && !menuRef.current.contains(e.target)) setMenuOpen(false);
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, []);

  const findColumnId = () => project.columns.find((c) => c.taskIds.includes(task.id))?.id;

  return (
    <div
      className={`task-card priority-${task.priority} ${dragging ? "dragging" : ""} ${task.completed ? "completed" : ""}`}
      draggable
      onDragStart={(e) => onDragStart(e, task.id)}
      onDragEnd={onDragEnd}
      onClick={() => onOpen(task.id)}
      role="button"
      tabIndex={0}
      onKeyDown={(e) => {
        if (e.key === "Enter") onOpen(task.id);
      }}
    >
      <div className="task-card-top">
        <PriorityBadge priority={task.priority} />
        <div className="task-card-menu" ref={menuRef}>
          <button
            className="btn-icon"
            onClick={(e) => {
              e.stopPropagation();
              setMenuOpen((v) => !v);
            }}
            aria-label="Task options"
          >
            <MoreHorizontal size={16} />
          </button>
          {menuOpen && (
            <div className="task-card-dropdown fade-in">
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  duplicateTask(project.id, findColumnId(), task.id);
                  setMenuOpen(false);
                }}
              >
                <Copy size={14} /> Duplicate
              </button>
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  toggleTaskComplete(project.id, task.id);
                  setMenuOpen(false);
                }}
              >
                <CheckSquare size={14} /> {task.completed ? "Mark incomplete" : "Mark complete"}
              </button>
              <button
                className="danger"
                onClick={(e) => {
                  e.stopPropagation();
                  deleteTask(project.id, task.id);
                  setMenuOpen(false);
                }}
              >
                <Trash2 size={14} /> Delete
              </button>
            </div>
          )}
        </div>
      </div>

      <p className={`task-card-title ${task.completed ? "strike" : ""}`}>{task.title}</p>

      {task.labels.length > 0 && (
        <div className="task-card-labels">
          {task.labels.map((l) => (
            <span key={l} className="chip">
              {l}
            </span>
          ))}
        </div>
      )}

      <div className="task-card-footer">
        <div className="task-card-meta">
          {task.dueDate && (
            <span className={`task-due ${overdue ? "overdue" : ""} ${dueToday ? "due-today" : ""}`}>
              {formatDate(task.dueDate)}
            </span>
          )}
          {task.checklist.length > 0 && (
            <span className="task-meta-chip">
              <CheckSquare size={12} /> {checklistDone}/{task.checklist.length}
            </span>
          )}
          {task.comments.length > 0 && (
            <span className="task-meta-chip">
              <MessageSquare size={12} /> {task.comments.length}
            </span>
          )}
          {task.attachments.length > 0 && (
            <span className="task-meta-chip">
              <Paperclip size={12} /> {task.attachments.length}
            </span>
          )}
        </div>
        <Avatar user={assignee} size={26} />
      </div>
    </div>
  );
}
