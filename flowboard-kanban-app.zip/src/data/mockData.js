export const mockUsers = [
  { id: "u1", name: "Amara Chen", initials: "AC", color: "#5b5fef", role: "Product Designer" },
  { id: "u2", name: "Diego Ferreira", initials: "DF", color: "#ff7a59", role: "Frontend Engineer" },
  { id: "u3", name: "Priya Nair", initials: "PN", color: "#2fbf71", role: "Backend Engineer" },
  { id: "u4", name: "Tomasz Wolski", initials: "TW", color: "#f5a623", role: "QA Lead" },
  { id: "u5", name: "Sade Bello", initials: "SB", color: "#e5484d", role: "Product Manager" },
];

export const currentUser = mockUsers[0];

const iso = (daysFromNow) => {
  const d = new Date();
  d.setDate(d.getDate() + daysFromNow);
  return d.toISOString();
};

function makeTask(overrides) {
  return {
    id: overrides.id,
    title: overrides.title,
    description: overrides.description || "",
    priority: overrides.priority || "medium",
    dueDate: overrides.dueDate ?? null,
    labels: overrides.labels || [],
    assigneeId: overrides.assigneeId || null,
    checklist: overrides.checklist || [],
    attachments: overrides.attachments || [],
    comments: overrides.comments || [],
    activity: overrides.activity || [
      { id: `${overrides.id}-a1`, type: "created", text: "Task created", at: iso(-4) },
    ],
    completed: overrides.completed || false,
    createdAt: overrides.createdAt || iso(-4),
  };
}

export const initialProjects = [
  {
    id: "p1",
    name: "Aurora Mobile App",
    color: "#5b5fef",
    icon: "🌅",
    favorite: true,
    archived: false,
    createdAt: iso(-40),
    columns: [
      {
        id: "c1",
        name: "Backlog",
        taskIds: ["t1", "t2", "t9"],
      },
      {
        id: "c2",
        name: "To Do",
        taskIds: ["t3", "t4"],
      },
      {
        id: "c3",
        name: "In Progress",
        taskIds: ["t5"],
      },
      {
        id: "c4",
        name: "Review",
        taskIds: ["t6"],
      },
      {
        id: "c5",
        name: "Completed",
        taskIds: ["t7", "t8"],
      },
    ],
    tasks: {
      t1: makeTask({
        id: "t1",
        title: "Define onboarding flow copy",
        description: "Draft the microcopy for the 4-step onboarding carousel, including empty and error states.",
        priority: "low",
        dueDate: iso(9),
        labels: ["Content", "Design"],
        assigneeId: "u1",
        checklist: [
          { id: "cl1", text: "Draft screen 1-2 copy", done: true },
          { id: "cl2", text: "Draft screen 3-4 copy", done: false },
        ],
      }),
      t2: makeTask({
        id: "t2",
        title: "Research push notification providers",
        priority: "low",
        labels: ["Research"],
        assigneeId: "u3",
      }),
      t9: makeTask({
        id: "t9",
        title: "Audit accessibility of color palette",
        priority: "medium",
        labels: ["Design", "Accessibility"],
        assigneeId: "u1",
        dueDate: iso(14),
      }),
      t3: makeTask({
        id: "t3",
        title: "Build settings screen UI",
        priority: "medium",
        dueDate: iso(3),
        labels: ["Frontend"],
        assigneeId: "u2",
        checklist: [
          { id: "cl3", text: "Layout profile section", done: true },
          { id: "cl4", text: "Wire theme toggle", done: false },
          { id: "cl5", text: "Wire notification prefs", done: false },
        ],
      }),
      t4: makeTask({
        id: "t4",
        title: "Set up biometric login",
        priority: "high",
        dueDate: iso(6),
        labels: ["Security", "Frontend"],
        assigneeId: "u2",
      }),
      t5: makeTask({
        id: "t5",
        title: "Implement offline sync queue",
        description: "Tasks created offline should queue and sync once connectivity resumes.",
        priority: "high",
        dueDate: iso(1),
        labels: ["Backend", "Frontend"],
        assigneeId: "u3",
        comments: [
          { id: "cm1", authorId: "u5", text: "Let's make sure conflict resolution favors latest edit.", at: iso(-1) },
        ],
      }),
      t6: makeTask({
        id: "t6",
        title: "Review new avatar upload flow",
        priority: "medium",
        dueDate: iso(0),
        labels: ["Design"],
        assigneeId: "u4",
      }),
      t7: makeTask({
        id: "t7",
        title: "Set up CI pipeline for mobile builds",
        priority: "medium",
        labels: ["DevOps"],
        assigneeId: "u3",
        completed: true,
      }),
      t8: makeTask({
        id: "t8",
        title: "Finalize brand color tokens",
        priority: "low",
        labels: ["Design"],
        assigneeId: "u1",
        completed: true,
      }),
    },
  },
  {
    id: "p2",
    name: "Northwind Marketing Site",
    color: "#ff7a59",
    icon: "📣",
    favorite: false,
    archived: false,
    createdAt: iso(-20),
    columns: [
      { id: "c6", name: "Backlog", taskIds: ["t10"] },
      { id: "c7", name: "To Do", taskIds: ["t11"] },
      { id: "c8", name: "In Progress", taskIds: ["t12"] },
      { id: "c9", name: "Review", taskIds: [] },
      { id: "c10", name: "Completed", taskIds: ["t13"] },
    ],
    tasks: {
      t10: makeTask({
        id: "t10",
        title: "Write Q3 case study",
        priority: "low",
        labels: ["Content"],
        assigneeId: "u5",
      }),
      t11: makeTask({
        id: "t11",
        title: "Rebuild pricing page",
        priority: "high",
        dueDate: iso(2),
        labels: ["Frontend", "Design"],
        assigneeId: "u2",
      }),
      t12: makeTask({
        id: "t12",
        title: "A/B test hero headline",
        priority: "medium",
        dueDate: iso(5),
        labels: ["Growth"],
        assigneeId: "u5",
      }),
      t13: makeTask({
        id: "t13",
        title: "Launch newsletter signup widget",
        priority: "medium",
        labels: ["Frontend"],
        assigneeId: "u2",
        completed: true,
      }),
    },
  },
  {
    id: "p3",
    name: "Internal Tools Revamp",
    color: "#2fbf71",
    icon: "🛠️",
    favorite: false,
    archived: false,
    createdAt: iso(-8),
    columns: [
      { id: "c11", name: "Backlog", taskIds: ["t14", "t15"] },
      { id: "c12", name: "To Do", taskIds: [] },
      { id: "c13", name: "In Progress", taskIds: [] },
      { id: "c14", name: "Review", taskIds: [] },
      { id: "c15", name: "Completed", taskIds: [] },
    ],
    tasks: {
      t14: makeTask({ id: "t14", title: "Consolidate admin dashboards", priority: "medium", assigneeId: "u4" }),
      t15: makeTask({ id: "t15", title: "Deprecate legacy reporting tool", priority: "low", assigneeId: "u3" }),
    },
  },
];

export const initialNotifications = [
  { id: "n1", type: "completed", text: "Diego marked \"Launch newsletter signup widget\" complete", at: iso(-1), read: false },
  { id: "n2", type: "due", text: "\"Review new avatar upload flow\" is due today", at: iso(0), read: false },
  { id: "n3", type: "project", text: "New project \"Internal Tools Revamp\" was created", at: iso(-8), read: true },
  { id: "n4", type: "comment", text: "Sade commented on \"Implement offline sync queue\"", at: iso(-1), read: false },
  { id: "n5", type: "due", text: "\"Rebuild pricing page\" is due in 2 days", at: iso(-1), read: true },
];

export const initialActivity = [
  { id: "act1", text: "Amara created task \"Audit accessibility of color palette\"", at: iso(-3) },
  { id: "act2", text: "Diego moved \"Set up biometric login\" to To Do", at: iso(-2) },
  { id: "act3", text: "Priya completed \"Set up CI pipeline for mobile builds\"", at: iso(-2) },
  { id: "act4", text: "Sade commented on \"Implement offline sync queue\"", at: iso(-1) },
  { id: "act5", text: "Tomasz moved \"Review new avatar upload flow\" to Review", at: iso(-1) },
  { id: "act6", text: "New project \"Internal Tools Revamp\" was created", at: iso(-8) },
];

export const weeklyThroughput = [
  { day: "Mon", completed: 3 },
  { day: "Tue", completed: 5 },
  { day: "Wed", completed: 2 },
  { day: "Thu", completed: 6 },
  { day: "Fri", completed: 4 },
  { day: "Sat", completed: 1 },
  { day: "Sun", completed: 0 },
];
