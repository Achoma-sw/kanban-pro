import { createContext, useContext, useMemo } from "react";
import { useLocalStorage } from "../hooks/useLocalStorage";
import { genId } from "../utils/id";
import {
  initialProjects,
  initialNotifications,
  initialActivity,
  mockUsers,
} from "../data/mockData";
import { useToast } from "./ToastContext";

const BoardContext = createContext(null);

export function BoardProvider({ children }) {
  const [projects, setProjects] = useLocalStorage("kanban:projects", initialProjects);
  const [notifications, setNotifications] = useLocalStorage("kanban:notifications", initialNotifications);
  const [activity, setActivity] = useLocalStorage("kanban:activity", initialActivity);
  const [recentlyViewed, setRecentlyViewed] = useLocalStorage("kanban:recent", []);
  const { showToast } = useToast();

  const logActivity = (text) => {
    setActivity((list) => [{ id: genId("act"), text, at: new Date().toISOString() }, ...list].slice(0, 100));
  };

  const pushNotification = (type, text) => {
    setNotifications((list) => [
      { id: genId("notif"), type, text, at: new Date().toISOString(), read: false },
      ...list,
    ]);
  };

  // ---------- Projects ----------
  const createProject = (name, icon = "📋") => {
    const id = genId("p");
    const colors = ["#5b5fef", "#ff7a59", "#2fbf71", "#f5a623", "#e5484d"];
    const project = {
      id,
      name,
      color: colors[Math.floor(Math.random() * colors.length)],
      icon,
      favorite: false,
      archived: false,
      createdAt: new Date().toISOString(),
      columns: [
        { id: genId("c"), name: "Backlog", taskIds: [] },
        { id: genId("c"), name: "To Do", taskIds: [] },
        { id: genId("c"), name: "In Progress", taskIds: [] },
        { id: genId("c"), name: "Review", taskIds: [] },
        { id: genId("c"), name: "Completed", taskIds: [] },
      ],
      tasks: {},
    };
    setProjects((list) => [...list, project]);
    logActivity(`Created project "${name}"`);
    pushNotification("project", `New project "${name}" was created`);
    return project;
  };

  const renameProject = (projectId, name) => {
    setProjects((list) => list.map((p) => (p.id === projectId ? { ...p, name } : p)));
  };

  const deleteProject = (projectId) => {
    const project = projects.find((p) => p.id === projectId);
    setProjects((list) => list.filter((p) => p.id !== projectId));
    if (project) {
      showToast(`Deleted "${project.name}"`, {
        type: "danger",
        action: {
          label: "Undo",
          onClick: () => setProjects((list) => [...list, project]),
        },
      });
    }
  };

  const archiveProject = (projectId, archived = true) => {
    setProjects((list) => list.map((p) => (p.id === projectId ? { ...p, archived } : p)));
  };

  const toggleFavorite = (projectId) => {
    setProjects((list) => list.map((p) => (p.id === projectId ? { ...p, favorite: !p.favorite } : p)));
  };

  // ---------- Columns ----------
  const updateColumns = (projectId, updater) => {
    setProjects((list) =>
      list.map((p) => (p.id === projectId ? { ...p, columns: updater(p.columns) } : p))
    );
  };

  const addColumn = (projectId, name) => {
    updateColumns(projectId, (cols) => [...cols, { id: genId("c"), name, taskIds: [] }]);
  };

  const renameColumn = (projectId, columnId, name) => {
    updateColumns(projectId, (cols) => cols.map((c) => (c.id === columnId ? { ...c, name } : c)));
  };

  const deleteColumn = (projectId, columnId) => {
    updateColumns(projectId, (cols) => cols.filter((c) => c.id !== columnId));
  };

  const reorderColumns = (projectId, fromIndex, toIndex) => {
    updateColumns(projectId, (cols) => {
      const next = [...cols];
      const [moved] = next.splice(fromIndex, 1);
      next.splice(toIndex, 0, moved);
      return next;
    });
  };

  // ---------- Tasks ----------
  const addTask = (projectId, columnId, taskData) => {
    const id = genId("t");
    const task = {
      id,
      title: taskData.title,
      description: taskData.description || "",
      priority: taskData.priority || "medium",
      dueDate: taskData.dueDate || null,
      labels: taskData.labels || [],
      assigneeId: taskData.assigneeId || null,
      checklist: [],
      attachments: [],
      comments: [],
      completed: false,
      createdAt: new Date().toISOString(),
      activity: [{ id: genId("a"), type: "created", text: "Task created", at: new Date().toISOString() }],
    };
    setProjects((list) =>
      list.map((p) => {
        if (p.id !== projectId) return p;
        return {
          ...p,
          tasks: { ...p.tasks, [id]: task },
          columns: p.columns.map((c) => (c.id === columnId ? { ...c, taskIds: [...c.taskIds, id] } : c)),
        };
      })
    );
    logActivity(`Created task "${task.title}"`);
    return task;
  };

  const updateTask = (projectId, taskId, patch, activityText) => {
    setProjects((list) =>
      list.map((p) => {
        if (p.id !== projectId) return p;
        const existing = p.tasks[taskId];
        const nextTask = { ...existing, ...patch };
        if (activityText) {
          nextTask.activity = [
            { id: genId("a"), type: "edited", text: activityText, at: new Date().toISOString() },
            ...(existing.activity || []),
          ];
        }
        return { ...p, tasks: { ...p.tasks, [taskId]: nextTask } };
      })
    );
  };

  const toggleTaskComplete = (projectId, taskId) => {
    setProjects((list) =>
      list.map((p) => {
        if (p.id !== projectId) return p;
        const task = p.tasks[taskId];
        const completed = !task.completed;
        if (completed) pushNotification("completed", `Task "${task.title}" was marked complete`);
        return {
          ...p,
          tasks: {
            ...p.tasks,
            [taskId]: {
              ...task,
              completed,
              activity: [
                {
                  id: genId("a"),
                  type: "completed",
                  text: completed ? "Marked complete" : "Marked incomplete",
                  at: new Date().toISOString(),
                },
                ...task.activity,
              ],
            },
          },
        };
      })
    );
  };

  const deleteTask = (projectId, taskId) => {
    const project = projects.find((p) => p.id === projectId);
    const task = project?.tasks[taskId];
    setProjects((list) =>
      list.map((p) => {
        if (p.id !== projectId) return p;
        const tasks = { ...p.tasks };
        delete tasks[taskId];
        return {
          ...p,
          tasks,
          columns: p.columns.map((c) => ({ ...c, taskIds: c.taskIds.filter((id) => id !== taskId) })),
        };
      })
    );
    if (task) {
      showToast(`Deleted "${task.title}"`, {
        type: "danger",
        action: {
          label: "Undo",
          onClick: () => {
            setProjects((list) =>
              list.map((p) => {
                if (p.id !== projectId) return p;
                const column = p.columns.find((c) => c.name === "Backlog") || p.columns[0];
                return {
                  ...p,
                  tasks: { ...p.tasks, [taskId]: task },
                  columns: p.columns.map((c) =>
                    c.id === column.id ? { ...c, taskIds: [...c.taskIds, taskId] } : c
                  ),
                };
              })
            );
          },
        },
      });
    }
  };

  const duplicateTask = (projectId, columnId, taskId) => {
    setProjects((list) =>
      list.map((p) => {
        if (p.id !== projectId) return p;
        const original = p.tasks[taskId];
        const newId = genId("t");
        const copy = {
          ...original,
          id: newId,
          title: `${original.title} (copy)`,
          completed: false,
          createdAt: new Date().toISOString(),
          activity: [{ id: genId("a"), type: "created", text: "Duplicated from another task", at: new Date().toISOString() }],
        };
        return {
          ...p,
          tasks: { ...p.tasks, [newId]: copy },
          columns: p.columns.map((c) => (c.id === columnId ? { ...c, taskIds: [...c.taskIds, newId] } : c)),
        };
      })
    );
  };

  const moveTask = (projectId, taskId, fromColumnId, toColumnId, toIndex) => {
    setProjects((list) =>
      list.map((p) => {
        if (p.id !== projectId) return p;
        const columns = p.columns.map((c) => ({ ...c, taskIds: [...c.taskIds] }));
        const fromCol = columns.find((c) => c.id === fromColumnId);
        const toCol = columns.find((c) => c.id === toColumnId);
        const fromIndex = fromCol.taskIds.indexOf(taskId);
        if (fromIndex === -1) return p;
        fromCol.taskIds.splice(fromIndex, 1);
        const insertAt = toIndex ?? toCol.taskIds.length;
        toCol.taskIds.splice(insertAt, 0, taskId);
        return { ...p, columns };
      })
    );
  };

  const addChecklistItem = (projectId, taskId, text) => {
    setProjects((list) =>
      list.map((p) => {
        if (p.id !== projectId) return p;
        const task = p.tasks[taskId];
        return {
          ...p,
          tasks: {
            ...p.tasks,
            [taskId]: { ...task, checklist: [...task.checklist, { id: genId("cl"), text, done: false }] },
          },
        };
      })
    );
  };

  const toggleChecklistItem = (projectId, taskId, itemId) => {
    setProjects((list) =>
      list.map((p) => {
        if (p.id !== projectId) return p;
        const task = p.tasks[taskId];
        return {
          ...p,
          tasks: {
            ...p.tasks,
            [taskId]: {
              ...task,
              checklist: task.checklist.map((it) => (it.id === itemId ? { ...it, done: !it.done } : it)),
            },
          },
        };
      })
    );
  };

  const deleteChecklistItem = (projectId, taskId, itemId) => {
    setProjects((list) =>
      list.map((p) => {
        if (p.id !== projectId) return p;
        const task = p.tasks[taskId];
        return {
          ...p,
          tasks: { ...p.tasks, [taskId]: { ...task, checklist: task.checklist.filter((it) => it.id !== itemId) } },
        };
      })
    );
  };

  const addComment = (projectId, taskId, text, authorId) => {
    setProjects((list) =>
      list.map((p) => {
        if (p.id !== projectId) return p;
        const task = p.tasks[taskId];
        return {
          ...p,
          tasks: {
            ...p.tasks,
            [taskId]: {
              ...task,
              comments: [...task.comments, { id: genId("cm"), text, authorId, at: new Date().toISOString() }],
              activity: [
                { id: genId("a"), type: "comment", text: "Comment added", at: new Date().toISOString() },
                ...task.activity,
              ],
            },
          },
        };
      })
    );
    pushNotification("comment", `New comment added to a task`);
  };

  const markTaskViewed = (projectId, taskId) => {
    setRecentlyViewed((list) => {
      const filtered = list.filter((r) => !(r.projectId === projectId && r.taskId === taskId));
      return [{ projectId, taskId, at: new Date().toISOString() }, ...filtered].slice(0, 8);
    });
  };

  const markNotificationRead = (id) => {
    setNotifications((list) => list.map((n) => (n.id === id ? { ...n, read: true } : n)));
  };

  const markAllNotificationsRead = () => {
    setNotifications((list) => list.map((n) => ({ ...n, read: true })));
  };

  const exportBoard = (projectId) => {
    const project = projects.find((p) => p.id === projectId);
    return JSON.stringify(project, null, 2);
  };

  const importBoard = (jsonString) => {
    try {
      const parsed = JSON.parse(jsonString);
      const id = genId("p");
      const project = { ...parsed, id, name: `${parsed.name} (imported)` };
      setProjects((list) => [...list, project]);
      return { success: true };
    } catch {
      return { success: false, error: "Invalid JSON file." };
    }
  };

  const stats = useMemo(() => {
    const activeProjects = projects.filter((p) => !p.archived);
    let totalTasks = 0;
    let completed = 0;
    let dueToday = 0;
    activeProjects.forEach((p) => {
      Object.values(p.tasks).forEach((t) => {
        totalTasks += 1;
        if (t.completed) completed += 1;
        if (t.dueDate) {
          const due = new Date(t.dueDate).toDateString();
          if (due === new Date().toDateString() && !t.completed) dueToday += 1;
        }
      });
    });
    return { totalProjects: activeProjects.length, totalTasks, completed, dueToday };
  }, [projects]);

  const value = {
    projects,
    users: mockUsers,
    notifications,
    activity,
    recentlyViewed,
    stats,
    createProject,
    renameProject,
    deleteProject,
    archiveProject,
    toggleFavorite,
    addColumn,
    renameColumn,
    deleteColumn,
    reorderColumns,
    addTask,
    updateTask,
    toggleTaskComplete,
    deleteTask,
    duplicateTask,
    moveTask,
    addChecklistItem,
    toggleChecklistItem,
    deleteChecklistItem,
    addComment,
    markTaskViewed,
    markNotificationRead,
    markAllNotificationsRead,
    exportBoard,
    importBoard,
    logActivity,
  };

  return <BoardContext.Provider value={value}>{children}</BoardContext.Provider>;
}

export function useBoard() {
  const ctx = useContext(BoardContext);
  if (!ctx) throw new Error("useBoard must be used within BoardProvider");
  return ctx;
}
