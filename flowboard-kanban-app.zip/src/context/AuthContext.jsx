import { createContext, useContext } from "react";
import { useLocalStorage } from "../hooks/useLocalStorage";
import { currentUser } from "../data/mockData";

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useLocalStorage("kanban:user", null);

  const login = ({ email }) => {
    setUser({ ...currentUser, email: email || "amara@aurora.co" });
    return { success: true };
  };

  const register = ({ name, email }) => {
    setUser({ ...currentUser, name: name || currentUser.name, email: email || "amara@aurora.co" });
    return { success: true };
  };

  const logout = () => setUser(null);

  return (
    <AuthContext.Provider value={{ user, login, register, logout, isAuthenticated: !!user }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used within AuthProvider");
  return ctx;
}
