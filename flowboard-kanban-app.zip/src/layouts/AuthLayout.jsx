import { Outlet } from "react-router-dom";

export default function AuthLayout() {
  return (
    <div className="auth-layout">
      <div className="auth-visual">
        <div className="auth-visual-inner">
          <div className="brand-mark large">◈</div>
          <h1>Flowboard</h1>
          <p>Plan sprints, track momentum, and ship together — one board at a time.</p>
          <div className="auth-visual-cards">
            <div className="floating-card fc1">
              <span className="badge" style={{ background: "rgba(47,191,113,0.16)", color: "#1f9c5a" }}>
                Low
              </span>
              <p>Draft onboarding copy</p>
            </div>
            <div className="floating-card fc2">
              <span className="badge" style={{ background: "rgba(229,72,77,0.16)", color: "#c8383d" }}>
                High
              </span>
              <p>Ship offline sync queue</p>
            </div>
            <div className="floating-card fc3">
              <span className="badge" style={{ background: "rgba(245,166,35,0.18)", color: "#c98212" }}>
                Medium
              </span>
              <p>Review avatar upload flow</p>
            </div>
          </div>
        </div>
      </div>
      <div className="auth-form-side">
        <Outlet />
      </div>
    </div>
  );
}
