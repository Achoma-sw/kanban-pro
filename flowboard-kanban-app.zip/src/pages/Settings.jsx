import { useState, useRef } from "react";
import { Sun, Moon, ArchiveRestore, Download, Upload } from "lucide-react";
import { useAuth } from "../context/AuthContext";
import { useTheme } from "../context/ThemeContext";
import { useBoard } from "../context/BoardContext";
import { useToast } from "../context/ToastContext";
import { useLocalStorage } from "../hooks/useLocalStorage";

export default function Settings() {
  const { user } = useAuth();
  const { theme, setTheme } = useTheme();
  const { projects, archiveProject, deleteProject, exportBoard, importBoard } = useBoard();
  const { showToast } = useToast();
  const [name, setName] = useState(user?.name || "");
  const [notifPrefs, setNotifPrefs] = useLocalStorage("kanban:notifPrefs", {
    email: true,
    push: true,
    weeklyDigest: false,
    mentions: true,
  });
  const [language, setLanguage] = useLocalStorage("kanban:language", "en");
  const fileInputRef = useRef(null);
  const archived = projects.filter((p) => p.archived);

  const handleImport = (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      const result = importBoard(reader.result);
      showToast(result.success ? "Board imported successfully" : result.error, {
        type: result.success ? "success" : "danger",
      });
    };
    reader.readAsText(file);
    e.target.value = "";
  };

  const handleExport = (project) => {
    const json = exportBoard(project.id);
    const blob = new Blob([json], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${project.name.replace(/\s+/g, "-").toLowerCase()}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="page-container fade-in settings-page">
      <h2>Settings</h2>

      <section className="settings-section card-surface">
        <h4>Profile</h4>
        <div className="field">
          <label>Full name</label>
          <input value={name} onChange={(e) => setName(e.target.value)} />
        </div>
        <div className="field">
          <label>Email</label>
          <input value={user?.email || ""} disabled />
        </div>
        <button className="btn btn-primary" style={{ alignSelf: "flex-start" }} onClick={() => showToast("Profile saved", { type: "success" })}>
          Save changes
        </button>
      </section>

      <section className="settings-section card-surface">
        <h4>Password</h4>
        <p className="muted-text small">UI only — password changes aren't wired up to a backend in this demo.</p>
        <div className="field">
          <label>Current password</label>
          <input type="password" placeholder="••••••••" />
        </div>
        <div className="field">
          <label>New password</label>
          <input type="password" placeholder="••••••••" />
        </div>
        <button className="btn btn-outline" style={{ alignSelf: "flex-start" }}>
          Update password
        </button>
      </section>

      <section className="settings-section card-surface">
        <h4>Appearance</h4>
        <div className="theme-toggle-row">
          <button className={`theme-option ${theme === "light" ? "active" : ""}`} onClick={() => setTheme("light")}>
            <Sun size={16} /> Light
          </button>
          <button className={`theme-option ${theme === "dark" ? "active" : ""}`} onClick={() => setTheme("dark")}>
            <Moon size={16} /> Dark
          </button>
        </div>
      </section>

      <section className="settings-section card-surface">
        <h4>Language</h4>
        <div className="field" style={{ maxWidth: 260 }}>
          <select value={language} onChange={(e) => setLanguage(e.target.value)}>
            <option value="en">English</option>
            <option value="es">Español</option>
            <option value="fr">Français</option>
            <option value="de">Deutsch</option>
            <option value="pt">Português</option>
          </select>
        </div>
      </section>

      <section className="settings-section card-surface">
        <h4>Notification preferences</h4>
        {[
          { key: "email", label: "Email notifications" },
          { key: "push", label: "Push notifications" },
          { key: "weeklyDigest", label: "Weekly digest" },
          { key: "mentions", label: "Mentions and comments" },
        ].map((row) => (
          <label key={row.key} className="switch-row">
            <span>{row.label}</span>
            <span className="switch">
              <input
                type="checkbox"
                checked={notifPrefs[row.key]}
                onChange={() => setNotifPrefs((p) => ({ ...p, [row.key]: !p[row.key] }))}
              />
              <span className="switch-track" />
            </span>
          </label>
        ))}
      </section>

      <section className="settings-section card-surface">
        <h4>Export & import boards</h4>
        <p className="muted-text small">Export a project to JSON, or import a previously exported board.</p>
        <div className="export-list">
          {projects.map((p) => (
            <div key={p.id} className="export-row">
              <span>{p.icon} {p.name}</span>
              <button className="btn btn-ghost btn-sm" onClick={() => handleExport(p)}>
                <Download size={13} /> Export
              </button>
            </div>
          ))}
        </div>
        <button className="btn btn-outline" style={{ alignSelf: "flex-start" }} onClick={() => fileInputRef.current?.click()}>
          <Upload size={14} /> Import board JSON
        </button>
        <input ref={fileInputRef} type="file" accept="application/json" hidden onChange={handleImport} />
      </section>

      {archived.length > 0 && (
        <section className="settings-section card-surface">
          <h4>Archived projects</h4>
          {archived.map((p) => (
            <div key={p.id} className="export-row">
              <span>{p.icon} {p.name}</span>
              <div style={{ display: "flex", gap: 8 }}>
                <button className="btn btn-ghost btn-sm" onClick={() => archiveProject(p.id, false)}>
                  <ArchiveRestore size={13} /> Restore
                </button>
                <button className="btn btn-danger-outline btn-sm" onClick={() => deleteProject(p.id)}>
                  Delete
                </button>
              </div>
            </div>
          ))}
        </section>
      )}
    </div>
  );
}
