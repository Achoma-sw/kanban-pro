import { Activity as ActivityIcon } from "lucide-react";
import { useBoard } from "../context/BoardContext";
import { relativeTime, formatDate } from "../utils/date";
import EmptyState from "../components/EmptyState";

export default function Activity() {
  const { activity } = useBoard();

  return (
    <div className="page-container fade-in">
      <div className="section-header-row">
        <h2>Activity</h2>
        <p className="muted-text small">A running log of everything happening across your workspace.</p>
      </div>

      {activity.length === 0 ? (
        <EmptyState icon="🕐" title="Nothing yet" message="Actions across your boards will show up here." />
      ) : (
        <div className="card-surface timeline">
          {activity.map((a) => (
            <div key={a.id} className="timeline-item">
              <div className="timeline-marker">
                <ActivityIcon size={13} />
              </div>
              <div className="timeline-content">
                <p>{a.text}</p>
                <span className="muted-text small" title={formatDate(a.at)}>
                  {relativeTime(a.at)}
                </span>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
