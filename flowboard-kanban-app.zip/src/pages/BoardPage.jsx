import { useState, useMemo } from "react";
import { useParams, useNavigate, useSearchParams } from "react-router-dom";
import { Star, Archive, Trash2, Pencil, Filter, X } from "lucide-react";
import { useBoard } from "../context/BoardContext";
import Board from "../components/Board";
import TaskModal from "../components/TaskModal";
import EmptyState from "../components/EmptyState";

export default function BoardPage() {
  const { projectId } = useParams();
  const navigate = useNavigate();
  const { projects, renameProject, deleteProject, archiveProject, toggleFavorite, users } = useBoard();
  const [searchParams, setSearchParams] = useSearchParams();
  const [renaming, setRenaming] = useState(false);
  const [nameValue, setNameValue] = useState("");
  const [filtersOpen, setFiltersOpen] = useState(false);
  const [filters, setFilters] = useState({ priority: "", label: "", assignee: "", status: "" });

  const project = projects.find((p) => p.id === projectId);
  const openTaskId = searchParams.get("task");

  const allLabels = useMemo(() => {
    if (!project) return [];
    const set = new Set();
    Object.values(project.tasks).forEach((t) => t.labels.forEach((l) => set.add(l)));
    return [...set];
  }, [project]);

  const filteredProject = useMemo(() => {
    if (!project) return null;
    const hasFilters = filters.priority || filters.label || filters.assignee || filters.status;
    if (!hasFilters) return project;
    const filterFn = (task) => {
      if (filters.priority && task.priority !== filters.priority) return false;
      if (filters.label && !task.labels.includes(filters.label)) return false;
      if (filters.assignee && task.assigneeId !== filters.assignee) return false;
      if (filters.status === "completed" && !task.completed) return false;
      if (filters.status === "active" && task.completed) return false;
      return true;
    };
    return {
      ...project,
      columns: project.columns.map((c) => ({
        ...c,
        taskIds: c.taskIds.filter((id) => project.tasks[id] && filterFn(project.tasks[id])),
      })),
    };
  }, [project, filters]);

  if (!project) {
    return (
      <EmptyState
        icon="🔍"
        title="Project not found"
        message="It may have been deleted or archived."
        action={
          <button className="btn btn-primary" onClick={() => navigate("/dashboard")}>
            Back to dashboard
          </button>
        }
      />
    );
  }

  const openTask = openTaskId ? project.tasks[openTaskId] : null;

  const startRename = () => {
    setNameValue(project.name);
    setRenaming(true);
  };

  const commitRename = () => {
    if (nameValue.trim()) renameProject(project.id, nameValue.trim());
    setRenaming(false);
  };

  const clearFilters = () => setFilters({ priority: "", label: "", assignee: "", status: "" });
  const activeFilterCount = Object.values(filters).filter(Boolean).length;

  return (
    <div className="board-page fade-in">
      <div className="board-page-header">
        <div className="board-title-row">
          <span className="project-tile-icon" style={{ background: `${project.color}22`, color: project.color }}>
            {project.icon}
          </span>
          {renaming ? (
            <input
              autoFocus
              className="board-title-input"
              value={nameValue}
              onChange={(e) => setNameValue(e.target.value)}
              onBlur={commitRename}
              onKeyDown={(e) => e.key === "Enter" && commitRename()}
            />
          ) : (
            <h2>{project.name}</h2>
          )}
          <button className="btn-icon" onClick={() => toggleFavorite(project.id)} aria-label="Toggle favorite">
            <Star size={18} fill={project.favorite ? "var(--warning)" : "none"} color={project.favorite ? "var(--warning)" : "currentColor"} />
          </button>
        </div>

        <div className="board-actions">
          <button className={`btn btn-outline btn-sm ${activeFilterCount ? "has-filters" : ""}`} onClick={() => setFiltersOpen((v) => !v)}>
            <Filter size={14} /> Filters {activeFilterCount > 0 && `(${activeFilterCount})`}
          </button>
          <button className="btn-icon" onClick={startRename} aria-label="Rename project" title="Rename">
            <Pencil size={16} />
          </button>
          <button className="btn-icon" onClick={() => archiveProject(project.id, true)} aria-label="Archive project" title="Archive">
            <Archive size={16} />
          </button>
          <button
            className="btn-icon"
            onClick={() => {
              if (window.confirm(`Delete "${project.name}"? This can be undone from the toast that appears.`)) {
                deleteProject(project.id);
                navigate("/dashboard");
              }
            }}
            aria-label="Delete project"
            title="Delete"
          >
            <Trash2 size={16} />
          </button>
        </div>
      </div>

      {filtersOpen && (
        <div className="filters-bar card-surface fade-in">
          <div className="field">
            <label>Priority</label>
            <select value={filters.priority} onChange={(e) => setFilters((f) => ({ ...f, priority: e.target.value }))}>
              <option value="">Any</option>
              <option value="low">Low</option>
              <option value="medium">Medium</option>
              <option value="high">High</option>
            </select>
          </div>
          <div className="field">
            <label>Label</label>
            <select value={filters.label} onChange={(e) => setFilters((f) => ({ ...f, label: e.target.value }))}>
              <option value="">Any</option>
              {allLabels.map((l) => (
                <option key={l} value={l}>
                  {l}
                </option>
              ))}
            </select>
          </div>
          <div className="field">
            <label>Assignee</label>
            <select value={filters.assignee} onChange={(e) => setFilters((f) => ({ ...f, assignee: e.target.value }))}>
              <option value="">Any</option>
              {users.map((u) => (
                <option key={u.id} value={u.id}>
                  {u.name}
                </option>
              ))}
            </select>
          </div>
          <div className="field">
            <label>Status</label>
            <select value={filters.status} onChange={(e) => setFilters((f) => ({ ...f, status: e.target.value }))}>
              <option value="">Any</option>
              <option value="active">Active</option>
              <option value="completed">Completed</option>
            </select>
          </div>
          {activeFilterCount > 0 && (
            <button className="btn btn-ghost btn-sm" onClick={clearFilters}>
              <X size={13} /> Clear
            </button>
          )}
        </div>
      )}

      <Board project={filteredProject} onOpenTask={(taskId) => setSearchParams({ task: taskId })} />

      {openTask && (
        <TaskModal
          project={project}
          task={openTask}
          onClose={() => {
            searchParams.delete("task");
            setSearchParams(searchParams);
          }}
        />
      )}
    </div>
  );
}
