import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Mail, Lock, Eye, EyeOff } from "lucide-react";
import { useAuth } from "../context/AuthContext";

export default function Login() {
  const { login } = useAuth();
  const navigate = useNavigate();
  const [email, setEmail] = useState("amara@aurora.co");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState("");

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!email.trim() || !password.trim()) {
      setError("Enter an email and password to continue.");
      return;
    }
    login({ email });
    navigate("/dashboard");
  };

  return (
    <div className="auth-card fade-in">
      <h2>Welcome back</h2>
      <p className="auth-subtitle">Sign in to keep your boards moving.</p>

      <form onSubmit={handleSubmit} className="auth-form">
        <div className="field">
          <label htmlFor="email">Email</label>
          <div className="input-with-icon">
            <Mail size={16} />
            <input id="email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@company.com" />
          </div>
        </div>
        <div className="field">
          <label htmlFor="password">Password</label>
          <div className="input-with-icon">
            <Lock size={16} />
            <input
              id="password"
              type={showPassword ? "text" : "password"}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••"
            />
            <button type="button" className="input-icon-btn" onClick={() => setShowPassword((v) => !v)} aria-label="Toggle password visibility">
              {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
            </button>
          </div>
        </div>

        {error && <p className="form-error">{error}</p>}

        <div className="auth-row">
          <label className="checkbox-row">
            <input type="checkbox" defaultChecked /> Remember me
          </label>
          <Link to="/forgot-password" className="link-btn">
            Forgot password?
          </Link>
        </div>

        <button type="submit" className="btn btn-primary btn-block">
          Sign in
        </button>
      </form>

      <p className="auth-switch">
        Don't have an account? <Link to="/register">Create one</Link>
      </p>
    </div>
  );
}
