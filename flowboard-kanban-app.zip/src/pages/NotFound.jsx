import { Link } from "react-router-dom";

export default function NotFound() {
  return (
    <div className="page-container fade-in" style={{ textAlign: "center", paddingTop: 80 }}>
      <h1 style={{ fontSize: "3rem" }}>404</h1>
      <p className="muted-text">This page doesn't exist.</p>
      <Link to="/dashboard" className="btn btn-primary" style={{ marginTop: 16, display: "inline-flex" }}>
        Back to dashboard
      </Link>
    </div>
  );
}
