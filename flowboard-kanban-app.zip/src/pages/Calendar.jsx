import { useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { useBoard } from "../context/BoardContext";
import PriorityBadge from "../components/PriorityBadge";

const WEEKDAYS = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];

export default function Calendar() {
  const { projects } = useBoard();
  const navigate = useNavigate();
  const [cursor, setCursor] = useState(new Date());

  const tasksByDate = useMemo(() => {
    const map = {};
    projects
      .filter((p) => !p.archived)
      .forEach((p) => {
        Object.values(p.tasks).forEach((t) => {
          if (!t.dueDate) return;
          const key = new Date(t.dueDate).toDateString();
          map[key] = map[key] || [];
          map[key].push({ task: t, project: p });
        });
      });
    return map;
  }, [projects]);

  const year = cursor.getFullYear();
  const month = cursor.getMonth();
  const firstDay = new Date(year, month, 1);
  const startOffset = firstDay.getDay();
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const today = new Date();

  const cells = [];
  for (let i = 0; i < startOffset; i++) cells.push(null);
  for (let d = 1; d <= daysInMonth; d++) cells.push(d);

  const monthLabel = cursor.toLocaleDateString(undefined, { month: "long", year: "numeric" });

  return (
    <div className="page-container fade-in">
      <div className="section-header-row">
        <h2>{monthLabel}</h2>
        <div className="calendar-nav">
          <button className="btn-icon" onClick={() => setCursor(new Date(year, month - 1, 1))} aria-label="Previous month">
            <ChevronLeft size={18} />
          </button>
          <button className="btn btn-ghost btn-sm" onClick={() => setCursor(new Date())}>
            Today
          </button>
          <button className="btn-icon" onClick={() => setCursor(new Date(year, month + 1, 1))} aria-label="Next month">
            <ChevronRight size={18} />
          </button>
        </div>
      </div>

      <div className="calendar-grid card-surface">
        {WEEKDAYS.map((w) => (
          <div key={w} className="calendar-weekday">
            {w}
          </div>
        ))}
        {cells.map((day, i) => {
          if (day === null) return <div key={`empty-${i}`} className="calendar-cell empty" />;
          const dateObj = new Date(year, month, day);
          const isToday = dateObj.toDateString() === today.toDateString();
          const items = tasksByDate[dateObj.toDateString()] || [];
          return (
            <div key={day} className={`calendar-cell ${isToday ? "today" : ""}`}>
              <span className="calendar-day-num">{day}</span>
              <div className="calendar-cell-tasks">
                {items.slice(0, 3).map(({ task, project }) => (
                  <button
                    key={task.id}
                    className={`calendar-task-chip priority-${task.priority}`}
                    onClick={() => navigate(`/boards/${project.id}?task=${task.id}`)}
                    title={task.title}
                  >
                    {task.title}
                  </button>
                ))}
                {items.length > 3 && <span className="muted-text small">+{items.length - 3} more</span>}
              </div>
            </div>
          );
        })}
      </div>

      <div className="card-surface" style={{ marginTop: 20, padding: 16 }}>
        <h4 style={{ marginBottom: 10 }}>Upcoming this week</h4>
        <div className="upcoming-list">
          {Object.entries(tasksByDate)
            .flatMap(([, items]) => items)
            .filter(({ task }) => !task.completed)
            .sort((a, b) => new Date(a.task.dueDate) - new Date(b.task.dueDate))
            .slice(0, 6)
            .map(({ task, project }) => (
              <button key={task.id} className="upcoming-item" onClick={() => navigate(`/boards/${project.id}?task=${task.id}`)}>
                <span className="truncate">{task.title}</span>
                <PriorityBadge priority={task.priority} />
              </button>
            ))}
        </div>
      </div>
    </div>
  );
}
