import { useNavigate } from "react-router-dom";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from "recharts";
import { FolderKanban, ListChecks, CheckCircle2, AlarmClock, Star, ArrowUpRight, Clock3 } from "lucide-react";
import { useBoard } from "../context/BoardContext";
import { useAuth } from "../context/AuthContext";
import StatCard from "../components/StatCard";
import EmptyState from "../components/EmptyState";
import { weeklyThroughput } from "../data/mockData";
import { relativeTime } from "../utils/date";

export default function Dashboard() {
  const { projects, stats, toggleFavorite, recentlyViewed } = useBoard();
  const { user } = useAuth();
  const navigate = useNavigate();
  const active = projects.filter((p) => !p.archived);

  const recentTasks = recentlyViewed
    .map((r) => {
      const project = projects.find((p) => p.id === r.projectId);
      const task = project?.tasks[r.taskId];
      return task ? { project, task, at: r.at } : null;
    })
    .filter(Boolean);

  return (
    <div className="page-container fade-in">
      <div className="dashboard-hello">
        <h2>Good to see you, {user?.name?.split(" ")[0] || "there"} 👋</h2>
        <p>Here's what's moving across your workspace today.</p>
      </div>

      <div className="stat-grid">
        <StatCard icon={<FolderKanban size={20} color="#5b5fef" />} tint="rgba(91,95,239,0.12)" label="Total Projects" value={stats.totalProjects} />
        <StatCard icon={<ListChecks size={20} color="#ff7a59" />} tint="rgba(255,122,89,0.12)" label="Total Tasks" value={stats.totalTasks} />
        <StatCard icon={<CheckCircle2 size={20} color="#2fbf71" />} tint="rgba(47,191,113,0.12)" label="Tasks Completed" value={stats.completed} />
        <StatCard icon={<AlarmClock size={20} color="#e5484d" />} tint="rgba(229,72,77,0.12)" label="Tasks Due Today" value={stats.dueToday} />
      </div>

      <div className="dashboard-grid">
        <div className="card-surface chart-card">
          <div className="section-header-row">
            <h4>Weekly throughput</h4>
            <span className="muted-text small">Tasks completed, mock data</span>
          </div>
          <ResponsiveContainer width="100%" height={220}>
            <BarChart data={weeklyThroughput} margin={{ top: 8, right: 8, left: -20, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="var(--border)" />
              <XAxis dataKey="day" stroke="var(--text-muted)" fontSize={12} tickLine={false} axisLine={false} />
              <YAxis stroke="var(--text-muted)" fontSize={12} tickLine={false} axisLine={false} allowDecimals={false} />
              <Tooltip
                contentStyle={{ background: "var(--surface)", border: "1px solid var(--border)", borderRadius: 10, fontSize: 13 }}
              />
              <Bar dataKey="completed" fill="#5b5fef" radius={[6, 6, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        <div className="card-surface recent-card">
          <div className="section-header-row">
            <h4>
              <Clock3 size={15} style={{ verticalAlign: "-3px" }} /> Recently viewed
            </h4>
          </div>
          {recentTasks.length === 0 ? (
            <p className="muted-text small">Open a task and it'll show up here.</p>
          ) : (
            <ul className="recent-list">
              {recentTasks.map(({ project, task, at }) => (
                <li key={task.id}>
                  <button onClick={() => navigate(`/boards/${project.id}?task=${task.id}`)}>
                    <span className="truncate">{task.title}</span>
                    <span className="muted-text small">{relativeTime(at)}</span>
                  </button>
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>

      <div className="section-header-row" style={{ marginTop: 8 }}>
        <h3>Your projects</h3>
      </div>

      {active.length === 0 ? (
        <EmptyState icon="📋" title="No projects yet" message="Create a project from the sidebar to get started." />
      ) : (
        <div className="project-grid">
          {active.map((p) => {
            const taskList = Object.values(p.tasks);
            const done = taskList.filter((t) => t.completed).length;
            const pct = taskList.length ? Math.round((done / taskList.length) * 100) : 0;
            return (
              <button key={p.id} className="project-tile card-surface" onClick={() => navigate(`/boards/${p.id}`)}>
                <div className="project-tile-top">
                  <span className="project-tile-icon" style={{ background: `${p.color}22`, color: p.color }}>
                    {p.icon}
                  </span>
                  <button
                    className="btn-icon"
                    onClick={(e) => {
                      e.stopPropagation();
                      toggleFavorite(p.id);
                    }}
                    aria-label="Toggle favorite"
                  >
                    <Star size={16} fill={p.favorite ? "var(--warning)" : "none"} color={p.favorite ? "var(--warning)" : "currentColor"} />
                  </button>
                </div>
                <h4>{p.name}</h4>
                <p className="muted-text small">{taskList.length} tasks · {done} done</p>
                <div className="progress-bar">
                  <div className="progress-bar-fill" style={{ width: `${pct}%`, background: p.color }} />
                </div>
                <span className="project-tile-open">
                  Open board <ArrowUpRight size={14} />
                </span>
              </button>
            );
          })}
        </div>
      )}
    </div>
  );
}
