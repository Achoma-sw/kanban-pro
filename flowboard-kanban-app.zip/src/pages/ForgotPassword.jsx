import { useState } from "react";
import { Link } from "react-router-dom";
import { Mail, ArrowLeft, CheckCircle2 } from "lucide-react";

export default function ForgotPassword() {
  const [email, setEmail] = useState("");
  const [sent, setSent] = useState(false);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (email.trim()) setSent(true);
  };

  if (sent) {
    return (
      <div className="auth-card fade-in">
        <div className="auth-success-icon">
          <CheckCircle2 size={32} />
        </div>
        <h2>Check your inbox</h2>
        <p className="auth-subtitle">
          If an account exists for <strong>{email}</strong>, we've sent a link to reset your password.
        </p>
        <Link to="/login" className="btn btn-outline btn-block">
          <ArrowLeft size={15} /> Back to sign in
        </Link>
      </div>
    );
  }

  return (
    <div className="auth-card fade-in">
      <h2>Reset your password</h2>
      <p className="auth-subtitle">Enter your email and we'll send you a reset link.</p>

      <form onSubmit={handleSubmit} className="auth-form">
        <div className="field">
          <label htmlFor="email">Email</label>
          <div className="input-with-icon">
            <Mail size={16} />
            <input id="email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@company.com" />
          </div>
        </div>
        <button type="submit" className="btn btn-primary btn-block">
          Send reset link
        </button>
      </form>

      <p className="auth-switch">
        <Link to="/login">
          <ArrowLeft size={13} style={{ verticalAlign: "-2px" }} /> Back to sign in
        </Link>
      </p>
    </div>
  );
}
