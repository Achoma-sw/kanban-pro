import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { User, Mail, Lock } from "lucide-react";
import { useAuth } from "../context/AuthContext";

export default function Register() {
  const { register } = useAuth();
  const navigate = useNavigate();
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!name.trim() || !email.trim() || !password.trim()) {
      setError("Fill in every field to create your account.");
      return;
    }
    register({ name, email });
    navigate("/dashboard");
  };

  return (
    <div className="auth-card fade-in">
      <h2>Create your account</h2>
      <p className="auth-subtitle">Set up your workspace in under a minute.</p>

      <form onSubmit={handleSubmit} className="auth-form">
        <div className="field">
          <label htmlFor="name">Full name</label>
          <div className="input-with-icon">
            <User size={16} />
            <input id="name" value={name} onChange={(e) => setName(e.target.value)} placeholder="Jordan Lee" />
          </div>
        </div>
        <div className="field">
          <label htmlFor="email">Email</label>
          <div className="input-with-icon">
            <Mail size={16} />
            <input id="email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@company.com" />
          </div>
        </div>
        <div className="field">
          <label htmlFor="password">Password</label>
          <div className="input-with-icon">
            <Lock size={16} />
            <input id="password" type="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Create a password" />
          </div>
        </div>

        {error && <p className="form-error">{error}</p>}

        <button type="submit" className="btn btn-primary btn-block">
          Create account
        </button>
      </form>

      <p className="auth-switch">
        Already have an account? <Link to="/login">Sign in</Link>
      </p>
    </div>
  );
}
